# Design System: Educational Editorial

## 1. Overview & Creative North Star
**The Creative North Star: "The Guided Luminary"**

This design system moves away from the sterile, "template-box" feel of traditional EdTech. Instead, it adopts a **High-End Editorial** aesthetic—blending the authority of a premium linguistic journal with the modern energy of a digital-first learning platform. 

We break the "standard" web layout by utilizing **intentional asymmetry** and **breathable white space**. By treating the interface as a physical workspace rather than a screen, we use the vibrant yellow accent not just as a color, but as a "highlighter" that guides the student's eye toward progress and action. The experience must feel light, expensive, and encouraging.

---

## 2. Colors: Tonal Depth & The "No-Line" Rule
The palette is rooted in high contrast (Black/White/Yellow), but we achieve sophistication through a nuanced scale of neutrals.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to section off content. Structural boundaries must be defined solely through background color shifts or tonal transitions.
*   **Example:** A `surface-container-low` (#f0f1f1) section sitting directly on a `surface` (#f6f6f6) background.

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked, fine paper sheets.
*   **Level 0 (Base):** `surface` (#f6f6f6) – The canvas for the entire page.
*   **Level 1 (Sections):** `surface-container` (#e7e8e8) – Use for large content blocks.
*   **Level 2 (Cards/Modules):** `surface-container-lowest` (#ffffff) – Used to pop important interactive elements off the page.

### The "Glass & Gradient" Rule
To prevent the "vibrant yellow" from feeling flat or "cheap," main CTAs and Hero backgrounds should use a subtle gradient from `primary` (#6d5a00) to `primary-container` (#fdd400). This provides a "soul" and a sense of light hitting the surface. 

For floating navigation or overlay panels, use **Glassmorphism**: 
*   **Token:** `surface` at 80% opacity + 20px backdrop-blur.

---

## 3. Typography: Authority Meets Clarity
The type system utilizes two distinct families to balance professional rigor with modern accessibility.

*   **Display & Headlines (Manrope):** A geometric sans-serif that feels authoritative yet open. 
    *   *Usage:* Use `display-lg` (3.5rem) with tight letter-spacing (-0.02em) for hero sections to create a bold, editorial impact.
*   **Body & Titles (Lexend):** Specifically designed to reduce visual stress and improve reading proficiency—perfect for an English learning context.
    *   *Usage:* `body-lg` (1rem) for lesson content to ensure maximum retention and comfort.

**Intentional Asymmetry:** Align headlines to the left while keeping body text in a narrower, centered column to create a "noted" editorial feel.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are largely replaced by **Tonal Layering**. We communicate "upward" movement by moving toward white.

*   **The Layering Principle:** Place a `surface-container-lowest` (#ffffff) card on a `surface-container-low` (#f0f1f1) background. This creates a soft, natural lift without the "dirtiness" of a gray shadow.
*   **Ambient Shadows:** If a floating effect is required (e.g., a mobile navigation bar), use a shadow color tinted with the brand: `rgba(45, 47, 47, 0.06)` with a 40px blur.
*   **The "Ghost Border":** If a container lacks contrast against its background, use the `outline-variant` (#acadad) at **15% opacity**. Never use 100% opaque borders.

---

## 5. Components: Style & Execution

### Buttons (The "Highlighters")
*   **Primary:** Background: `primary-fixed` (#fdd400); Text: `on-primary-fixed` (#433700). Roundedness: `md` (0.75rem). On hover, use a slight vertical lift (-2px) and a subtle gradient shift.
*   **Secondary:** Background: `secondary-container` (#e2e2e2); Text: `on-secondary` (#f3f3f3).
*   **Tertiary:** No background. Text uses `primary` (#6d5a00) with a `full` rounded underline that appears on hover.

### Progress Inputs (Learning Context)
*   **Input Fields:** Use `surface-container-lowest` (#ffffff) with a 2px bottom-border only, using the `primary` (#6d5a00) color when focused. This mimics a notebook line.
*   **Selection Chips:** Use `full` roundedness (9999px). Unselected: `surface-variant`. Selected: `primary-container`.

### Cards & Lists (No Dividers)
*   **The Rule:** Forbid the use of divider lines. Separate list items using `spacing-md` or by alternating backgrounds between `surface` and `surface-container-low`.
*   **Learning Cards:** Use `xl` (1.5rem) roundedness for a friendly, approachable feel.

### Specific Component: The "Word-Focus" Card
A unique component for learning: a `surface-container-highest` card with `display-sm` text, used to highlight specific English vocabulary. It should use a `primary` (#6d5a00) "ghost border" to feel like a premium flashcard.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use massive amounts of white space (minimum 80px between sections).
*   **Do** use the vibrant yellow (`primary-fixed`) sparingly to highlight *success* or *action*.
*   **Do** lean into asymmetrical layouts—e.g., a large headline on the left with a 4-column gap before the body text starts.

### Don’t:
*   **Don’t** use pure black (#000000) for text. Use `on-surface` (#2d2f2f) to maintain an editorial, "ink-on-paper" feel.
*   **Don’t** use "Card Shadows" on every element. Let the background colors do the heavy lifting.
*   **Don’t** use sharp corners. Use the `DEFAULT` (0.5rem) or `lg` (1rem) tokens to keep the "encouraging" brand voice.